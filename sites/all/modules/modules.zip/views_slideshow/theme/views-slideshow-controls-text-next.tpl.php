<span id="views_slideshow_controls_text_next_<?php print $variables['vss_id']; ?>" class="<?php print $classes; ?>"><a href="#"><?php print t('Next'); ?></a></span>
