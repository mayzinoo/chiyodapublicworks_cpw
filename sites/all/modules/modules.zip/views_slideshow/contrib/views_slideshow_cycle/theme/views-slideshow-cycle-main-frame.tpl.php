<div id="views_slideshow_cycle_teaser_section_<?php print $variables['vss_id']; ?>" class="<?php print $classes; ?>">
  <?php print $rendered_rows; ?>
</div>
